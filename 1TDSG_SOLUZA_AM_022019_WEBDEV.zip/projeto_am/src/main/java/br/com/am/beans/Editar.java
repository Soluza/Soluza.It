package br.com.am.beans;

import java.util.Calendar;

public class Editar {
	public int codigo;
	public Disciplina disciplina;
	public Administrador administrador;
	public Calendar dataInicio;
	public Calendar dataTermino;

	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public Disciplina getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(Disciplina disciplina) {
		this.disciplina = disciplina;
	}
	public Administrador getAdministrador() {
		return administrador;
	}
	public void setAdministrador(Administrador administrador) {
		this.administrador = administrador;
	}
	public Calendar getDataInicio() {
		return dataInicio;
	}
	public void setDataInicio(Calendar dataInicio) {
		this.dataInicio = dataInicio;
	}
	public Calendar getDataTermino() {
		return dataTermino;
	}
	public void setDataTermino(Calendar dataTermino) {
		this.dataTermino = dataTermino;
	}

	public Editar() {
		super();
	}

	public Editar(int codigo, Disciplina disciplina, Administrador administrador, Calendar dataInicio,
			Calendar dataTermino) {
		super();
		this.codigo = codigo;
		this.disciplina = disciplina;
		this.administrador = administrador;
		this.dataInicio = dataInicio;
		this.dataTermino = dataTermino;
	}

}
