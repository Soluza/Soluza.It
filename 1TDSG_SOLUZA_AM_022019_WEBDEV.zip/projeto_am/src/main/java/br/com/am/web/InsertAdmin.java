package br.com.am.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.am.beans.Administrador;
import br.com.am.dao.AdministradorDAO;

@WebServlet(urlPatterns="/")
public class InsertAdmin extends HttpServlet{

	private static final long serialVersionUID = -7277800883478737601L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		int codigo = req.getContentLength(); //req.getIntHeader("codigo")
		String nome = req.getParameter("nome");
		String email = req.getParameter("email");
		String senha = req.getParameter("senha");
		
		Administrador admin = new Administrador(codigo, nome, email, senha);
		new AdministradorDAO().adicionarAdmin(admin);

		out.println("<html><body>");

		out.println("<h2> O Administrador " + admin.getNome() + " foi cadastrado com sucesso.</h2>");

		out.print("<a href=\"index.html\"> Voltar para Home</a>");
		out.print("</body></html>");				// pegar os forms
		out.flush();
		out.close();
	}
}
