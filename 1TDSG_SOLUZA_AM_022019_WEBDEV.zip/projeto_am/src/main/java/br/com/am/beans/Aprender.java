package br.com.am.beans;

import java.util.Calendar;
import java.util.Date;

public class Aprender {
	public int codigo;
	public Aluno aluno;
	public Disciplina disciplina;
	public Capitulo capitulo;
	public Calendar dataEntrada;
	public Calendar dataSaida;
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public Aluno getAluno() {
		return aluno;
	}
	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}
	public Disciplina getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(Disciplina disciplina) {
		this.disciplina = disciplina;
	}
	public Capitulo getCapitulo() {
		return capitulo;
	}
	public void setCapitulo(Capitulo capitulo) {
		this.capitulo = capitulo;
	}
	public Calendar getDataEntrada() {
		return dataEntrada;
	}
	public void setDataEntrada(Calendar dataEntrada) {
		this.dataEntrada = dataEntrada;
	}
	public Calendar getDataSaida() {
		return dataSaida;
	}
	public void setDataSaida(Calendar dataSaida) {
		this.dataSaida = dataSaida;
	}
	
	public Aprender() {
		super();
	}
	
	public Aprender(int codigo, Aluno aluno, Disciplina disciplina, Capitulo capitulo, Calendar dataEntrada,
			Calendar dataSaida) {
		super();
		this.codigo = codigo;
		this.aluno = aluno;
		this.disciplina = disciplina;
		this.capitulo = capitulo;
		this.dataEntrada = dataEntrada;
		this.dataSaida = dataSaida;
	}
	
	
	
}

	
	