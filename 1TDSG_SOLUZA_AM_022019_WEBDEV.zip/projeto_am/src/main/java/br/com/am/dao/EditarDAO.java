package br.com.am.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import br.com.am.beans.Administrador;
import br.com.am.beans.Disciplina;
import br.com.am.beans.Editar;
import br.com.am.conexao.Conexao;

public class EditarDAO {
	private static ArrayList<Editar> EDITAR = new ArrayList();
	
	public void adicionarEditar(Editar edit) {
		EDITAR.add(edit);
	}
	
	public ArrayList<Editar> consultarEditar() {
		return EDITAR;
	}
	
	public Editar consultarPeloCodigo(int codigo) {
		for(Editar edit : EDITAR) {
			if(edit.getCodigo() == codigo) {
				return edit;
			}
		}
		return null;
	}
}
