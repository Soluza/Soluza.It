package br.com.am.dao;

import java.util.ArrayList;

import br.com.am.beans.Aprender;

public class AprenderDAO {
	private static ArrayList<Aprender> APRENDER = new ArrayList();

	public void adicionarAprender(Aprender apre) {
		APRENDER.add(apre);
	}

	public ArrayList<Aprender> consultarAprender() {
		return APRENDER;
	}

	public Aprender consultarPeloCodigo(int codigo) {
		for(Aprender apre : APRENDER) {
			if(apre.getCodigo() == codigo) {
				return apre;
			}
		}
		return null;
	}
}
