package br.com.am.beans;




public class Disciplina {
	public int codigo;
	public String nome;
	public String status;

	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public Disciplina() {
		super();
	}

	public Disciplina(int codigo, String nome, String status) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.status = status;
	}

}
