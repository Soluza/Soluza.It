package br.com.am.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.am.beans.Aluno;

@WebServlet(urlPatterns="/")
public class ConsultarAluno extends HttpServlet{

	private static final long serialVersionUID = 2689615498845203416L;
		
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		Aluno alun = (Aluno) session.getAttribute("aluno");
		
		if(alun != null) {
			resp.getWriter().println("<h1>codigo: " + alun.codigo + "</h1>");
			resp.getWriter().println("<h1>Nome: " + alun.nome + "</h1>");
			resp.getWriter().println("<h1>cpf: " + alun.cpf + "</h1>");
			resp.getWriter().println("<h1>Telefone: " + alun.telefone + "</h1>");
			resp.getWriter().println("<h1>Email: " + alun.email + "</h1>");
			resp.getWriter().println("<h1>Senha: " + alun.senha + "</h1>");
			}
	}
}
