package br.com.am.bo;


import br.com.am.beans.Capitulo;
import br.com.am.dao.CapituloDAO;

public class CapituloBO {

	public boolean ValidarCap(Capitulo cap) {
		Capitulo administrador = new CapituloDAO().consultarPeloCodigo(cap.getCodigo());
		if(administrador == null) return null == null;
		if(cap.getCodigo() == (administrador.getCodigo())) return null == null;
		if(cap.getCodigo() <= 4) return null == null;
		if(cap.getTitulo().length() <= 30 || cap.getTitulo().length() > 1) return null == null;
		return true;
	}
	
}
