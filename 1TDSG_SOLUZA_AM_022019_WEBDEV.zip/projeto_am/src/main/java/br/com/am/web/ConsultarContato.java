package br.com.am.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.am.beans.Contato;

@WebServlet(urlPatterns=("/"))
public class ConsultarContato extends HttpServlet{

	private static final long serialVersionUID = 5508798590332129599L;

		@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

			HttpSession session = req.getSession();
			Contato cont = (Contato) session.getAttribute("contato");
			
			if(cont != null) {
				resp.getWriter().println("<h1>codigo: " + cont.codigo + "</h1>");
				resp.getWriter().println("<h1>Codigo do Aluno: " + cont.aluno.codigo + "</h1>");
				resp.getWriter().println("<h1>Mensagem: " + cont.mensagem + "</h1>");
				}
		}
}
