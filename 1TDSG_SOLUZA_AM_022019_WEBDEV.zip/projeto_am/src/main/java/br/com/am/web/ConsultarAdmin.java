package br.com.am.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.am.beans.Administrador;

@WebServlet(urlPatterns="/")
public class ConsultarAdmin extends HttpServlet{

	private static final long serialVersionUID = 1023081629682846780L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		Administrador admin = (Administrador) session.getAttribute("administrador");
		
		if(admin != null) {
			resp.getWriter().println("<h1>codigo: " + admin.codigo + "</h1>");
			resp.getWriter().println("<h1>Nome: " + admin.nome + "</h1>");
			resp.getWriter().println("<h1>Email: " + admin.email + "</h1>");
			resp.getWriter().println("<h1>Senha: " + admin.senha + "</h1>");
			}
	}
}
