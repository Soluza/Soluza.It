package br.com.am.dao;

import java.util.ArrayList;

import br.com.am.beans.Administrador;

public class AdministradorDAO {
	private static ArrayList<Administrador> ADMIN = new ArrayList();
	
	public void adicionarAdmin(Administrador adm) {
		ADMIN.add(adm);
	}
	
	public ArrayList<Administrador> consultarAdmins(){
		return ADMIN;
	}
	
	public Administrador consultarPorEmail(String email) {
		for(Administrador adm : ADMIN) {
			if(adm.getEmail().equals(email)) {
				return adm;
			}
		}
		return null;
	}
}
