package br.com.am.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.am.beans.Disciplina;
import br.com.am.dao.DisciplinaDAO;

@WebServlet(urlPatterns="/")
public class InsertDisciplina extends HttpServlet{

	private static final long serialVersionUID = 4581190485921715368L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		int codigo = req.getContentLength();
		String nome = req.getParameter("nome");
		String status = req.getParameter("status");
		
		Disciplina disc = new Disciplina(codigo, nome, status);
		new DisciplinaDAO().adicionarDisciplina(disc);

		out.println("<html><body>");

		out.println("<h2> A Disciplina " + disc.getNome() + " foi adicionada com sucesso.</h2>");

		out.print("<a href=\"index.html\"> Voltar para Home</a>");
		out.print("</body></html>");				// pegar os forms
		out.flush();
		out.close();
	}
}
