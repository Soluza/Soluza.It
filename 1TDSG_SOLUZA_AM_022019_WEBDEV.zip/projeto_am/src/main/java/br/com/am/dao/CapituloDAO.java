package br.com.am.dao;

import java.util.ArrayList;

import br.com.am.beans.Capitulo;

public class CapituloDAO {
	private static ArrayList<Capitulo> CAPITULO = new ArrayList();

	public void adicionarCapitulo (Capitulo cap) {
		CAPITULO.add(cap);
	}

	public ArrayList<Capitulo> consultarCapitulo() {
		return CAPITULO;
	}

	public Capitulo consultarPeloCodigo(int codigo) {
		for(Capitulo cap : CAPITULO) {
			if(cap.getCodigo() == codigo) {
				return cap;
			}
		}
		return null;
	}
}
