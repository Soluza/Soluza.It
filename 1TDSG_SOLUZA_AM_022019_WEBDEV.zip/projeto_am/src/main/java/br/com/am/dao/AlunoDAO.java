package br.com.am.dao;

import java.util.ArrayList;

import br.com.am.beans.Administrador;
import br.com.am.beans.Aluno;

public class AlunoDAO {
private static ArrayList<Aluno> ALUNO = new ArrayList();
	
	public void adicionarAluno(Aluno alun) {
		ALUNO.add(alun);
	}
	
	public ArrayList<Aluno> consultarAlunos(){
		return ALUNO;
	}
	
	public Aluno consultarPorEmail(String email) {
		for(Aluno alun : ALUNO) {
			if(alun.getEmail().equals(email)) {
				return alun;
			}
		}
		return null;
	}
	
}
