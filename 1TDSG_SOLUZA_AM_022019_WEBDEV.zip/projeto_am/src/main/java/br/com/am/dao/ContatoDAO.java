package br.com.am.dao;

import java.util.ArrayList;

import br.com.am.beans.Contato;

public class ContatoDAO {
	private static ArrayList<Contato> CONTATO = new ArrayList();

	public void adicionarContato(Contato cont) {
		CONTATO.add(cont);
	}

	public ArrayList<Contato> consultarContato() {
		return CONTATO;
	}

	public Contato consultarPeloCodigo(int codigo) {
		for(Contato cont : CONTATO) {
			if(cont.getCodigo() == codigo) {
				return cont;
			}
		}
		return null;
	}
}
