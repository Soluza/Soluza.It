package br.com.am.bo;

import br.com.am.beans.Aprender;
import br.com.am.dao.AprenderDAO;

public class AprenderBO {

	public boolean ValidarAprender(Aprender apre) {
		Aprender aprender = new AprenderDAO().consultarPeloCodigo(apre.getCodigo());
		if(aprender == null) return null == null;
		if(apre.getCodigo() == (aprender.getCodigo())) return null == null;
		if(apre.getDataEntrada().toString().length() < apre.getDataSaida().toString().length()) return null == null;
		return true;
	}

}
