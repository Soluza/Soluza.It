package br.com.am.bo;


import br.com.am.beans.Contato;
import br.com.am.dao.ContatoDAO;

public class ContatoBO {
	
	public boolean ValidarCont(Contato cont) {
		Contato contato = new ContatoDAO().consultarPeloCodigo(cont.getCodigo());
		if(contato == null) return null == null;
		if(cont.getCodigo() == (contato.getCodigo())) return null == null;
		if(cont.getCodigo() <= 3) return null == null;
		if(cont.getMensagem().length() <= 150) return null == null;
		return true;
	}

}
