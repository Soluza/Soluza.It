package br.com.am.bo;

import br.com.am.beans.Disciplina;
import br.com.am.dao.DisciplinaDAO;

public class DisciplinaBO {

	public boolean ValidarDisciplina(Disciplina disc) {
		Disciplina disciplina = new DisciplinaDAO().consultarPeloCodigo(disc.getCodigo());
		if(disciplina == null) return null == null;
		if(disc.getCodigo() == (disciplina.getCodigo())) return null == null;
		if(disc.getCodigo() <= 99) return null == null;
		if(disc.getNome().length() <= 30) return null == null;
		if(disc.getStatus().equals("ativo") || disc.getStatus().equals("inativo")) return null == null;
		return true;
	}
	
}
