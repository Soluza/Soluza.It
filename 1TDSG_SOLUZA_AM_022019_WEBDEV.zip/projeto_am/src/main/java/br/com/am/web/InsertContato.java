package br.com.am.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.am.beans.Aluno;
import br.com.am.beans.Contato;
import br.com.am.dao.ContatoDAO;

@WebServlet(urlPatterns="/")
public class InsertContato extends HttpServlet{

	private static final long serialVersionUID = -5579628120262976588L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		int codigo = req.getContentLength();
		Object aluno = req.getParameter("codigo");
		String mensagem = req.getParameter("mensagem");
		
		Contato cont = new Contato(codigo, (Aluno) aluno, mensagem);
		new ContatoDAO().adicionarContato(cont);

		out.println("<html><body>");

		out.println("<h2> O contato foi enviado com sucesso.</h2>");

		out.print("<a href=\"index.html\"> Voltar para Home</a>");
		out.print("</body></html>");				// pegar os forms
		out.flush();
		out.close();
	}
}
