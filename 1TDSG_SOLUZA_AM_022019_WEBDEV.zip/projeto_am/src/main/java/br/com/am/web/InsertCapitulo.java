package br.com.am.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.am.beans.Capitulo;
import br.com.am.beans.Disciplina;
import br.com.am.dao.CapituloDAO;

@WebServlet(urlPatterns="/")
public class InsertCapitulo extends HttpServlet{

	private static final long serialVersionUID = 907172854789930241L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		int codigo = req.getContentLength();
		String titulo = req.getParameter("titulo");
		Object disciplina = req.getParameter("codigo");

		Capitulo cap = new Capitulo(codigo, titulo, (Disciplina) disciplina);
		new CapituloDAO().adicionarCapitulo(cap);

		out.println("<html><body>");

		out.println("<h2> O Capitulo " + cap.getTitulo() + " foi adicionado com sucesso.</h2>");

		out.print("<a href=\"index.html\"> Voltar para Home</a>");
		out.print("</body></html>");				// pegar os forms
		out.flush();
		out.close();
	}
}

