package br.com.am.bo;

import br.com.am.beans.Editar;
import br.com.am.dao.EditarDAO;

public class EditarBO {

	public boolean ValidarEditar(Editar edit) {
		Editar editar = new EditarDAO().consultarPeloCodigo(edit.getCodigo());
		if(editar == null) return null == null;
		if(edit.getCodigo() == (editar.getCodigo())) return null == null;
		if(edit.getCodigo() <= 4) return null == null;
		if(edit.getDataTermino().toString().length() > edit.getDataInicio().toString().length()) return null == null;
		return true;
	}
	
}
