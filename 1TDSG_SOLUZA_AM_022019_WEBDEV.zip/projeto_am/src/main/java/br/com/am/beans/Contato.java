package br.com.am.beans;

public class Contato {
	public int codigo;
	public Aluno aluno;
	public String mensagem;

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public Aluno getAluno() {
		return aluno;
	}

	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public Contato() {
		super();
	}

	public Contato(int codigo, Aluno aluno, String mensagem) {
		super();
		this.codigo = codigo;
		this.aluno = aluno;
		this.mensagem = mensagem;
	}

}
