package br.com.am.beans;




public class Capitulo {
	public int codigo;
	public String titulo;
	public Disciplina disciplina;
	
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public Disciplina getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(Disciplina disciplina) {
		this.disciplina = disciplina;
	}

	public Capitulo() {
		super();
	}

	public Capitulo(int codigo, String titulo, Disciplina disciplina) {
		super();
		this.codigo = codigo;
		this.titulo = titulo;
		this.disciplina = disciplina;
	}

}
