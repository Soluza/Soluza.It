package br.com.am.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.am.beans.Aluno;
import br.com.am.dao.AlunoDAO;

@WebServlet(urlPatterns="/login")
public class InsertAluno extends HttpServlet {
	private static final long serialVersionUID = -8914650684768374405L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		int codigo = req.getContentLength();
		String nome = req.getParameter("nome");
		String cpf = req.getParameter("cpf");
		int telefone = req.getContentLength();
		String email = req.getParameter("email");
		String senha = req.getParameter("senha");

		Aluno alun = new Aluno(codigo, nome,cpf,telefone, email, senha);
		new AlunoDAO().adicionarAluno(alun);

		out.println("<html><body>");

		out.println("<h2> O Aluno " + alun.getNome() + " foi cadastrado com sucesso.</h2>");

		out.print("<a href=\"index.html\"> Voltar para Home</a>");
		out.print("</body></html>");			
		out.flush();
		out.close();
	}
}

