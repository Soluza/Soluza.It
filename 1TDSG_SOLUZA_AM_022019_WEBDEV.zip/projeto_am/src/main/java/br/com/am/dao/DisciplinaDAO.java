package br.com.am.dao;

import java.util.ArrayList;

import br.com.am.beans.Disciplina;

public class DisciplinaDAO {
	private static ArrayList<Disciplina> DISCIPLINA = new ArrayList();

	public void adicionarDisciplina(Disciplina disc) {
		DISCIPLINA.add(disc);
	}
	
	public ArrayList<Disciplina> consultarDisciplina() {
		return DISCIPLINA;
	}
	
	public Disciplina consultarPeloCodigo(int codigo) {
		for(Disciplina disc : DISCIPLINA) {
			if(disc.getCodigo() == codigo) {
				return disc;
			}
		}
		return null;
	}

}
