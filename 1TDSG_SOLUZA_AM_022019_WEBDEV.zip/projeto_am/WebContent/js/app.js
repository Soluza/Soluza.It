var btnCadastrar = document.querySelector("#cadastrar");

btnCadastrar.addEventListener("click", function(event) {
	event.preventDefault();
	window.location = "cadastro.html";
});