
var btnCadastrar = document.querySelector("#cadastrar");

btnCadastrar.addEventListener("click", function(event) {
	event.preventDefault();
	window.location = "cadastro.html";
});

$('#meuModal').modal(options)

$(document).ready(function(){
   $('#login-form').submit(function() {
     data = $('#login-form').serialize();

     $.post("validar.php",{
            d: data,
     },
      function (d) {
        //console.log(d);
       if(d == 1){
           $('#myModal').modal('show');
        }else{
          var redirecionar = "pagina-de-acesso.php";
         $(window.document.location).attr('href',redirecionar);
        }
      });
      return false;
    });
});
