package br.com.am.validacao;

import java.sql.Connection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import br.com.am.conexao.Conexao;

public class ValidarEmail {
	public static boolean validar(String email) throws Exception { 
		Connection con = new Conexao().getConectar();
		boolean EmailValido = false;
		
		if (email != null && email.length() > 0) { 
			String regex = "/^[a-z0-9.]+@[a-z0-9]+\\.[a-z]+\\.([a-z]+)?$/i"; 
			Pattern EmailPat = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
			Matcher matcher = EmailPat.matcher(email); 
			if (matcher.matches()) { 
				EmailValido = true; 
				System.out.println("Email Cadastrado");
			} 
			System.out.println("Email incorreto");
		} 
		con.close();
		return EmailValido; 
	}
}
