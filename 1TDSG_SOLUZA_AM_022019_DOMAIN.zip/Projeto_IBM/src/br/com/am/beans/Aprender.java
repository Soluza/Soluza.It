package br.com.am.beans;

import java.util.Calendar;
import java.util.Date;

public class Aprender {
	private int codigo;
	private Aluno aluno;
	private Disciplina disciplina;
	private Capitulo capitulo;
	private Calendar dataEntrada;
	private Calendar dataSaida;
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public Aluno getAluno() {
		return aluno;
	}
	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}
	public Disciplina getDisciplina() {
		return disciplina;
	}
	public void setDisciplina(Disciplina disciplina) {
		this.disciplina = disciplina;
	}
	public Capitulo getCapitulo() {
		return capitulo;
	}
	public void setCapitulo(Capitulo capitulo) {
		this.capitulo = capitulo;
	}
	public Calendar getDataEntrada() {
		return dataEntrada;
	}
	public void setDataEntrada(Calendar dataEntrada) {
		this.dataEntrada = dataEntrada;
	}
	public Calendar getDataSaida() {
		return dataSaida;
	}
	public void setDataSaida(Calendar dataSaida) {
		this.dataSaida = dataSaida;
	}
	
	public Aprender() {
		super();
	}
	
	public Aprender(int codigo, Aluno aluno, Disciplina disciplina, Capitulo capitulo, Calendar dataEntrada,
			Calendar dataSaida) {
		super();
		this.codigo = codigo;
		this.aluno = aluno;
		this.disciplina = disciplina;
		this.capitulo = capitulo;
		this.dataEntrada = dataEntrada;
		this.dataSaida = dataSaida;
	}
	
	public void setTudo(int codigo, Aluno aluno, Disciplina disciplina, Capitulo capitulo, Calendar dataEntrada,
			Calendar dataSaida) {
		this.codigo = codigo;
		this.aluno = aluno;
		this.disciplina = disciplina;
		this.capitulo = capitulo;
		this.dataEntrada = dataEntrada;
		this.dataSaida = dataSaida;
	}
	
	public String getTudo() {
		return "Codigo:" + codigo + "\n"
			 + "Codigo do Aluno:"	+ aluno.getCodigo() + "\n"
			 + "Codigo da Dsciplina:" + disciplina.getCodigo() + "\n"
			 + "Codigo do Capitulo: " + capitulo.getCodigo() + "\n"
			 + "Data entrada:" + dataEntrada + "\n"
			 + "Data Saida:" + dataSaida + "\n";
	}

}
