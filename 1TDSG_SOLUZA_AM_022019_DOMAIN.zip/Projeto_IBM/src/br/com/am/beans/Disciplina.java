package br.com.am.beans;

import java.util.Calendar;
import java.util.Date;

public class Disciplina {
	private int codigo;
	private String nome;
	private String status;

	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public Disciplina() {
		super();
	}

	public Disciplina(int codigo, String nome, String status) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.status = status;
	}

	public void setTudo(int codigo, String nome, String status) {
		this.codigo = codigo;
		this.nome = nome;
		this.status = status;
	}

	public String getTudo() {
		return "C�digo: " + codigo + "\n"
				+ "Nome da disciplina: " + nome + "\n"
				+ "Status da disciplina: " + status + "\n";

	}

}
