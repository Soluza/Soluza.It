package br.com.am.beans;

import java.util.Calendar;
import java.util.Date;

public class Capitulo {
	private int codigo;
	private String titulo;
	private Disciplina disciplina;
	
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public Disciplina getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(Disciplina disciplina) {
		this.disciplina = disciplina;
	}

	public Capitulo() {
		super();
	}

	public Capitulo(int codigo, String titulo, Disciplina disciplina) {
		super();
		this.codigo = codigo;
		this.titulo = titulo;
		this.disciplina = disciplina;
	}

	public void setTudo(int codigo, String titulo, Disciplina disciplina) {
		this.codigo = codigo;
		this.titulo = titulo;
		this.disciplina = disciplina;
	}
	
	public String getTudo() {
		return "Codigo: " + codigo + "\n"
				+ "Titulo: " + titulo + "\n"
				+ "Codigo da Disciplina: " + disciplina.getCodigo() + "\n";

	}
	
	
	
	
	
}
