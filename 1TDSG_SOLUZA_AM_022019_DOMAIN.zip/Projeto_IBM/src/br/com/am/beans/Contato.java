package br.com.am.beans;

public class Contato {
	private int codigo;
	private Aluno aluno;
	private String mensagem;

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public Aluno getAluno() {
		return aluno;
	}

	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public Contato() {
		super();
	}

	public Contato(int codigo, Aluno aluno, String mensagem) {
		super();
		this.codigo = codigo;
		this.aluno = aluno;
		this.mensagem = mensagem;
	}

	public void setTudo(int codigo, Aluno aluno, String mensagem) {
		this.codigo = codigo;
		this.aluno = aluno;
		this.mensagem = mensagem;
	}

	public String getTudo() {
		return "Codigo do contato: " + codigo + "\n"
				+ "Codigo do Aluno: " + aluno.getCodigo() + "\n"
				+ "Mensagem do contato: " + mensagem + "\n";
	}
}
