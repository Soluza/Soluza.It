package br.com.am.beans;

import java.util.Calendar;
import java.util.Date;

public class Editar {
private int codigo;
private Disciplina disciplina;
private Administrador administrador;
private Calendar dataInicio;
private Calendar dataTermino;

public int getCodigo() {
	return codigo;
}
public void setCodigo(int codigo) {
	this.codigo = codigo;
}
public Disciplina getDisciplina() {
	return disciplina;
}
public void setDisciplina(Disciplina disciplina) {
	this.disciplina = disciplina;
}
public Administrador getAdministrador() {
	return administrador;
}
public void setAdministrador(Administrador administrador) {
	this.administrador = administrador;
}
public Calendar getDataInicio() {
	return dataInicio;
}
public void setDataInicio(Calendar dataInicio) {
	this.dataInicio = dataInicio;
}
public Calendar getDataTermino() {
	return dataTermino;
}
public void setDataTermino(Calendar dataTermino) {
	this.dataTermino = dataTermino;
}

public Editar() {
	super();
}

public Editar(int codigo, Disciplina disciplina, Administrador administrador, Calendar dataInicio,
		Calendar dataTermino) {
	super();
	this.codigo = codigo;
	this.disciplina = disciplina;
	this.administrador = administrador;
	this.dataInicio = dataInicio;
	this.dataTermino = dataTermino;
}

public void setTudo(int codigo, Disciplina disciplina, Administrador administrador, Calendar dataInicio,
		Calendar dataTermino) {
	this.codigo = codigo;
	this.disciplina = disciplina;
	this.administrador = administrador;
	this.dataInicio = dataInicio;
	this.dataTermino = dataTermino;
}

public String getTudo() {
	return "Codigo Editar: " + codigo + "\n"
			+ "Codigo da Disciplina: " + disciplina.getCodigo() + "\n"
			+ "Codigo do Administrador : " + administrador.getCodigo() + "\n"
			+ "Data de inicio : " + dataInicio + "\n"
			+ "Data de termino : " + dataTermino + "\n";
}


}
