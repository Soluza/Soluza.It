package br.com.am.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;

import br.com.am.beans.Administrador;
import br.com.am.beans.Disciplina;
import br.com.am.conexao.Conexao;
/**
 * @author Thalles Feige
 * @author Bruno Castro
 * @author Layon Guimar�es
 * @see Disciplina
 * @version 1.0.0
 */
public class DisciplinaDAO {
	private Connection con;
	private ResultSet rs;
	private PreparedStatement stmt;
	private Calendar cal;
	
	
	/**
	 * 
	 * @throws Exception
	 */
	public DisciplinaDAO() throws Exception {
		con = Conexao.getConectar();
	}
	
	
	/**
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public int adicionarDisciplina(Disciplina obj) throws Exception {
		stmt = con.prepareStatement("INSERT_INTO_T_TAL_DISCIPLINA"
									+ ("CD_DISCIPLINA, NM_DISCIPLINA, DS_STATUS")
									+ "VALUES (SQ_TAL_DISCIPLINA.nextval, ?, ?)");
		stmt.setString(1, obj.getNome());
		stmt.setString(2, obj.getStatus());
		return stmt.executeUpdate();
	}
	
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public Disciplina getDisciplina(int codigo) throws Exception {
		stmt = con.prepareStatement("SELECT * FROM T_TAL_DISCIPLINA WHERE CD_DISCIPLINA=?");
		stmt.setInt(1, codigo);
		ResultSet rs = stmt.executeQuery();
		if(rs.next()) {
			return new Disciplina(
					rs.getInt("CD_DISCIPLINA"),
					rs.getString("NM_DISCIPLINA"),
					rs.getString("DS_STATUS")
					);
		}else {
			return new Disciplina();
		}
	}
	
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public String deletarDisciplina(int codigo) throws Exception {
		stmt = con.prepareStatement("DELETE FROM T_TAL_DISCIPLINA WHERE CD_DISCIPLINA=?");
		stmt.setInt(1, codigo);
		if(stmt.executeUpdate() > 0) {
			return "Disciplina Deletada!";
		}else {
			return "Disciplina n�o encontrada";
		}	
	}
	
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public Disciplina consultarDiscPorCodigo (int codigo) throws Exception{
		if(codigo == 0 ) {               
			return new Disciplina();
		}else {
			DisciplinaDAO dao = new DisciplinaDAO();
			Disciplina dis = dao.getDisciplina(codigo);
			dao.fechar();
			return dis;
		}
	}
	
	/**
	 * 
	 * @throws Exception
	 */
	public void fechar() throws Exception {
		con.close();
	}
	
}
