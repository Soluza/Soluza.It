package br.com.am.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;

import br.com.am.beans.Aluno;
import br.com.am.beans.Aprender;
import br.com.am.beans.Capitulo;
import br.com.am.beans.Disciplina;
import br.com.am.conexao.Conexao;
/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Aprender
 */
public class AprenderDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	Calendar cal;
	Aluno alun;
	Disciplina disc;
	Aprender aprender;
	Capitulo cap;
	
	/**
	 * 
	 * @throws Exception
	 */
	public AprenderDAO() throws Exception{
		con = Conexao.getConectar();
	}
	
	/**
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public int adicionarAprender(Aprender obj) throws Exception{
		stmt = con.prepareStatement("INSERT INTO T_TAL_APRENDER"
				                     + "(CD_APRENDER, CD_ALUNO, CD_DISCIPLINA, CD_CAPITULO, DT_ENTRADA, DT_SAIDA)"
				                      + "VALUES(SQ_TAL_APRENDER.nextval ,?,?,?,?,?");
		stmt.setInt(1, obj.getAluno().getCodigo());
		stmt.setInt(2, obj.getDisciplina().getCodigo());
		stmt.setInt(3, obj.getCapitulo().getCodigo());
		stmt.setDate(4, new Date(obj.getDataEntrada().getTimeInMillis()));
		stmt.setDate(5, new Date(obj.getDataSaida().getTimeInMillis()));
		return stmt.executeUpdate();
	}
	
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public Aprender getAprender(int codigo)throws Exception{
		stmt = con.prepareStatement("SELECT * FROM T_TAL_APRENDER + INNER JOIN T_TAL_ALUNO"
									+ "+ ON T_TAL-ALUNO.CD_ALUNO = T_TAL_APRENDER.CD_ALUNO"
									+ "+ INNER JOIN T_TAL_DISCIPLINA ON "
									+ "+ T_TAL_DISCIPLINA.CD_DISCIPLINA = T_TAL_APRENDER.CD_DISCIPLINA"
									+ "+ INNER JOIN T_TAL_CAPITULO ON "
									+ "+ T_TAL_CAPITULO.CD_CAPITULO = T_TAL_APRENDER.CD_CAPITULO"
									+ "WHERE CD_ADMIN=?");
		stmt.setInt(1, codigo);
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			aprender = new Aprender();
			aprender.setCodigo(rs.getInt("CD_APRENDER"));
			disc = new Disciplina();
			disc.setCodigo(rs.getInt("CD_DISCIPLINA"));
			aprender.setDisciplina(disc);
			alun = new Aluno();
			alun.setCodigo(rs.getInt("CD_ALUNO"));
			aprender.setAluno(alun);
			cap = new Capitulo();
			cap.setCodigo(rs.getInt("CD_CAPITLO"));
			aprender.setCapitulo(cap);
			cal = Calendar.getInstance();
			cal.setTime(rs.getDate("DT_ENTRADA"));
			aprender.setDataEntrada(cal);
			cal = Calendar.getInstance();
			cal.setTime(rs.getDate("DT_SAIDA"));
			aprender.setDataSaida(cal);
		}
		return new Aprender();
	}
	
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public String deletarAprender(int codigo)throws Exception{
		con.prepareStatement("DELETE FROM T_TAL_APRENDER WHERE CD_APRENDER=?");
		stmt.setInt(1, codigo);
		if(stmt.executeUpdate() > 0) {
			return "Deletado com sucesso!";
		}else {
			return "Aprender n�o encontrador";
		}
	}
	
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public Aprender consultarAprenderPorCodigo (int codigo) throws Exception{
		if(codigo == 0 ) {               
			return new Aprender();
		}else {
			AprenderDAO dao = new AprenderDAO();
			Aprender apr = dao.getAprender(codigo);
			dao.fechar();
			return apr;
		}
	}
	/**
	 * 
	 * @throws Exception
	 */
	public void fechar() throws Exception{
		con.close();
	}
	
	
}
