package br.com.am.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;

import br.com.am.beans.Administrador;
import br.com.am.beans.Aluno;
import br.com.am.beans.Contato;
import br.com.am.conexao.Conexao;
/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Contato
 */
public class ContatoDAO {
	private Connection con;
	private ResultSet rs;
	private PreparedStatement stmt;
	Contato cont = null;
	Aluno aluno = null;

	/**
	 * 
	 * @throws Exception
	 */
	public ContatoDAO() throws Exception {
		con = Conexao.getConectar();
	}
	/**
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public int adicionarContato(Contato obj) throws Exception {
		stmt = con.prepareStatement("INSERT INTO T_TAL_CONTATO"
				+ "(CD_CONTATO,CD_ALUNO, DS_MSG)"
				+ "VALUES(SQ_TAL_CONTATO.nextval , ?, ?)");
		stmt.setInt(1, obj.getAluno().getCodigo());
		stmt.setString(2, obj.getMensagem());
		return stmt.executeUpdate();
	}
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public Contato getContato(int codigo) throws Exception {
		stmt = con.prepareStatement("SELECT * FROM T_TAL_CONTATO INNER JOIN T_TAL_ALUNO "
									+ "ON T_TAL_ALUNO.CD_ALUNO= T_TAL_CONTATO.CD_ALUNO WHERE CD_CONTATO=?");
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			cont = new Contato();
			cont.setCodigo(rs.getInt("CD_CONTATO"));
			cont.setMensagem(rs.getString("DS_MSG"));
			aluno = new Aluno();
			aluno.setCodigo(rs.getInt("CD_ALUNO"));
		}
		return new Contato();
	}
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public String deletarContato(int codigo) throws Exception {
		stmt = con.prepareStatement("DELETE FROM T_TAL_CONTATO WHERE CD_CONTATO=?");
		stmt.setInt(1, codigo);
		if(stmt.executeUpdate() > 0) {
			return "Apagado com sucesso!";
		}else {
			return "Contato n�o encontrado";
		}
	}
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public Contato consultarContatoPorCodigo (int codigo) throws Exception{
		if(codigo == 0 ) {               
			return new Contato();
		}else {
			ContatoDAO dao = new ContatoDAO();
			Contato ad = dao.getContato(codigo);
			dao.fechar();
			return ad;
		}
	}
	/**
	 * 
	 * @throws Exception
	 */
	public void fechar() throws Exception {
		con.close();
	}

}
