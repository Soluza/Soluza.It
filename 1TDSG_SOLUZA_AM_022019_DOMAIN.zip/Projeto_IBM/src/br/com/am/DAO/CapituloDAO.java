package br.com.am.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.am.beans.Capitulo;
import br.com.am.beans.Disciplina;
import br.com.am.conexao.Conexao;
/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Capitulo
 */
public class CapituloDAO {
	private Connection con;
	private ResultSet rs;
	private PreparedStatement stmt;
	Capitulo capitulo;
	Disciplina disc;
	/**
	 * 
	 * @throws Exception
	 */
	public CapituloDAO() throws Exception {
		con = Conexao.getConectar();
	}
	/**
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public int adicionarCapitulo(Capitulo obj) throws Exception{
		stmt = con.prepareStatement("INSERT INTO T_TAL_CAPITULO"
									+ ("CD_CAPITULO, DS_TITULO, CD_DISCIPLINA")      
									+ "VALUES (SQ_TAL_CAPITULO.nextval, ?, ?)");
		stmt.setString(1, obj.getTitulo());
		stmt.setInt(2, obj.getDisciplina().getCodigo());
		return stmt.executeUpdate();
	}
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public Capitulo getCapitulo(int codigo) throws Exception {
		stmt = con.prepareStatement("SELECT * FROM T_TAL_CAPITULO WHERE CD_CODIGO=?");
		stmt.setInt(1, codigo);
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
			capitulo = new Capitulo();
			capitulo.setCodigo(rs.getInt("CD_CAPITULO"));
			capitulo.setTitulo(rs.getString("DS_TITULO"));
			disc = new Disciplina();
			disc.setCodigo(rs.getInt("CD_DISCIPLINA"));
			capitulo.setDisciplina(disc);
		}
		return new Capitulo();
	}
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public String deletarCapitulo(int codigo) throws Exception {
		stmt = con.prepareStatement("DELETE FROM T_TAL_CAPITULO WHERE CD_CAPITULO=?");
		stmt.setInt(1, codigo);
		if(stmt.executeUpdate() > 0) {
			return "Capitulo Deletado";
		}else {
			return "Capitulo n�o encontrado";
		}
	}
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public Capitulo consultarCapPorCodigo (int codigo) throws Exception{
		if(codigo == 0 ) {               
			return new Capitulo();
		}else {
			CapituloDAO dao = new CapituloDAO();
			Capitulo cap = dao.getCapitulo(codigo);
			dao.fechar();
			return cap;
		}
	}
	/**
	 * 
	 * @throws Exception
	 */
	public void fechar() throws Exception{
		con.close();
	}





}
