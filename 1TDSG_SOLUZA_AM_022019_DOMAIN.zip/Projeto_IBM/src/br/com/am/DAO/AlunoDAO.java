package br.com.am.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.am.beans.Aluno;
import br.com.am.conexao.Conexao;
/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Aluno
 */
public class AlunoDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	/**
	 * 
	 * @throws Exception
	 */
	public AlunoDAO() throws Exception{
		con = Conexao.getConectar();
	}
	/**
	 * 
	 * @param email
	 * @return
	 * @throws Exception
	 */
	public Aluno getAluno(String email) throws Exception{
		stmt = con.prepareStatement
				("SELECT * FROM T_TAL_ALUNO WHERE DS_EMAIL=?");
		stmt.setString(1, email);
		ResultSet rs = stmt.executeQuery();
		if (rs.next()) {
			return new Aluno(
					rs.getInt("CD_ALUNO"),
					rs.getString("NM_ALUNO"),
					rs.getString("DS_CPF"),
					rs.getInt("NR_TELEFONE"),
					rs.getString("DS_EMAIL"),
					rs.getString("PW_SENHA")
					);
		}else {
			return new Aluno();
		}

	}
	/**
	 * 
	 * @param email
	 * @return
	 * @throws Exception
	 */
	public String apagarAluno(String email) throws Exception {
		con.prepareStatement("delete from T_TAL_ALUNO WHERE DS_EMAIL=?");
		stmt.setString(1, email);
		if (stmt.executeUpdate() > 0) {
			return "Deletado com Sucesso";
		}else {
			return "Aluno n�o cadastrado";
		}
	}

	/**
	 * 
	 * @param alun
	 * @return
	 * @throws Exception
	 */
	public int adicionarAluno(Aluno alun) throws Exception{
		stmt = con.prepareStatement("INSERT INTO T_TAL_ALUNO "
				+ "(CD_ALUNO, NM_ALUNO, DS_CPF, NR_TELEFONE, DS_EMAIL, PW_SENHA) "
				+ "VALUES (SQ_TAL_ALUNO.nextval,?,?,?,?,?)");
		stmt.setString(1, alun.getNome());
		stmt.setString(2, alun.getCpf());
		stmt.setInt(3, alun.getTelefone());
		stmt.setString(4, alun.getEmail());
		stmt.setString(5, alun.getSenha());
		return stmt.executeUpdate();   
	}

	/**
	 * 
	 * @param email
	 * @return
	 * @throws Exception
	 */
	public Aluno consultarAlunoPorEmail (String email) throws Exception{
		if(email.equals(null) ) {               
			return new Aluno();
		}else {
			AlunoDAO dao = new AlunoDAO();
			Aluno al = dao.getAluno(email);
			dao.fechar();
			return al;
		}
	}
	/**
	 * 
	 * @throws Exception
	 */
	public void fechar() throws Exception {
		con.close();
	}

}
