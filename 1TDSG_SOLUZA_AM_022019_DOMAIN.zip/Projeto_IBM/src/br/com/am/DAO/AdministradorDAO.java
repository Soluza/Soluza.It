package br.com.am.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.am.beans.Administrador;
import br.com.am.beans.Aluno;
import br.com.am.conexao.Conexao;
/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Administrador
 */
public class AdministradorDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	/**
	 * 
	 * @throws Exception
	 */
	public AdministradorDAO() throws Exception {
	 	con =  Conexao.getConectar();
	}
	/**
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public int adicionarAdmin(Administrador obj) throws Exception{
		stmt = con.prepareStatement("INSERT INTO T_TAL_ADMINISTRADOR "
									+ "(CD_ADMIN, NM_ADMIN, DS_EMAIL, DS_SENHA)"
									+ "VALUES(SQ_TAL_ADMINISTRADOR, ?, ?, ?)");
		stmt.setString(1, obj.getNome());
		stmt.setString(2, obj.getEmail());
		stmt.setString(3, obj.getSenha());
		return stmt.executeUpdate();
	}
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public Administrador getAdministrador(int codigo) throws Exception {
		stmt = con.prepareStatement("SELECT * FROM T_TAL_ADMINISTRADOR WHERE CD_ADMIN=?");
		stmt.setInt(1, codigo);
		ResultSet rs = stmt.executeQuery();
		if(rs.next()) {
			return new Administrador(
					rs.getInt("CD_ADMIN"),
					rs.getString("NM_ADMIN"),
					rs.getString("DS_EMAIL"),
					rs.getString("PW_SENHA")
					);
		}
		return new Administrador();
	}

	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public String deletarAdmin(int codigo) throws Exception {
		con.prepareStatement("DELETE FROM T_TAL_ADMINISTRADOR WHERE CD_ADMIN=?");
		stmt.setInt(1, codigo);
		if(stmt.executeUpdate() > 0) {
			return "Deletado com sucesso!";
		}else {
			return "Administrador n�o encontrado";
		}
	}
	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public Administrador consultarAdminPorCodigo (int codigo) throws Exception{
		if(codigo == 0 ) {               
			return new Administrador();
		}else {
			AdministradorDAO dao = new AdministradorDAO();
			Administrador ad = dao.getAdministrador(codigo);
			dao.fechar();
			return ad;
		}
	}
	/**
	 * 
	 * @throws Exception
	 */
	public void fechar() throws Exception{
		con.close();
	}
	
}
