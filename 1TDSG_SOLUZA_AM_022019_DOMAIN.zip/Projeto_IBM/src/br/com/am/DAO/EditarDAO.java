package br.com.am.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Date;

import br.com.am.beans.Administrador;
import br.com.am.beans.Disciplina;
import br.com.am.beans.Editar;
import br.com.am.conexao.Conexao;
/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Editar
 */
public class EditarDAO {
	private Connection con;
	private ResultSet rs;
	private PreparedStatement stmt;
	Calendar cal;
	Disciplina disciplina;
	Administrador admin;
	Editar editar;
	/**
	 * 
	 * @throws Exception
	 */
	public EditarDAO() throws Exception {
		con = Conexao.getConectar();
	}
	/**
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public int adicionarEditar(Editar obj) throws Exception {
		stmt = con.prepareStatement("INSERT INTO T_TAL_EDITAR"
									+ "CD_EDITAR, CD_DISCIPLINA, CD_ADMINISTRADOR, DT_INICIO, DT_TERMINO)"
									+ "VALUES(SQ_TAL_EDITAR.nextval, ?, ?, ?, ?)");
		stmt.setInt(1, obj.getDisciplina().getCodigo());
		stmt.setInt(2, obj.getAdministrador().getCodigo());
		stmt.setDate(3, (java.sql.Date) new Date(obj.getDataInicio().getTimeInMillis()));
		stmt.setDate(4, (java.sql.Date) new Date(obj.getDataTermino().getTimeInMillis()));
		return stmt.executeUpdate();
	}

	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public Editar getEditar(int codigo) throws Exception {
		stmt = con.prepareStatement("SELECT * FROM T_TAL_EDITAR + INNER JOIN T_TAL_DISCIPLINA "
				+ "+ ON T_TAL_DISCIPLINA.CD_DISCIPLINA = T_TAL_EDITAR.CD_DISCIPLINA "
				+ "+ INNER JOIN T_TAL_ADMINISTRADOR ON"
				+ "+ T_TAL_ADMINISTRADOR.CD_ADMINISTRADOR = T_TAL_EDITAR.CD_ADMINISTRADOR"
				+ "WHERE CD_EDITAR =?");
		stmt.setInt(1, codigo);
		ResultSet rs = stmt.executeQuery();
		while(rs.next()) {
		editar = new Editar();
		editar.setCodigo(rs.getInt("CD_EDITAR"));
		disciplina = new Disciplina();
		disciplina.setCodigo(rs.getInt("CD_DISCIPLINA"));
		editar.setDisciplina(disciplina);
		admin = new Administrador();
		admin.setCodigo(rs.getInt("CD_ADMINISTRADOR"));
		editar.setAdministrador(admin);
		cal = Calendar.getInstance();
		cal.setTime(rs.getDate("DT_INICIO"));
		editar.setDataInicio(cal);
		cal = Calendar.getInstance();
		cal.setTime(rs.getDate("DT_TERMINO"));
		editar.setDataTermino(cal);
		}
		return new Editar();
	}

	/**
	 * 
	 * @param codigo
	 * @return
	 * @throws Exception
	 */
	public String deletarEditar(int codigo) throws Exception{
		stmt = con.prepareStatement("DELETE FROM T_TAL_EDITAR WHERE CD_EDITAR = ?");
		if(stmt.executeUpdate() > 0) {
			return "Edi��o apagada com sucesso";
		}else{
			return "Edi��o n�o encontrada";
		}
	}
	/**
	 * 
	 * @throws Exception
	 */
	public void fechar() throws Exception {
		con.close();
	}

}
