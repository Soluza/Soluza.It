package br.com.am.teste;

import java.sql.Connection;

import br.com.am.conexao.Conexao;

public class TesteConexao {

	public static void main(String[] args) throws Exception{

		Connection c = new Conexao().getConectar();
		System.out.println("Conexao ta aberta");
		c.close();
	}
}
