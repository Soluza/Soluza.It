package br.com.am.principal;

import javax.swing.JOptionPane;

import br.com.am.BO.AlunoBO;
import br.com.am.beans.Aluno;

public class ConsultarAlunoPeloEmail {

	public static void main(String[] args) {
		try {
			AlunoBO alu = new AlunoBO();
			String email = (JOptionPane.showInputDialog("email"));
			Aluno obj = alu.consultarAlunoPeloEmail(email);
			System.out.println(obj.getNome());
			System.out.println(obj.getCpf());
			System.out.println(obj.getEmail());
			System.out.println(obj.getSenha());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		
		
	}

}
