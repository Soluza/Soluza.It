package br.com.am.principal;

import br.com.am.BO.AdministradorBO;
import br.com.am.DAO.AdministradorDAO;
import br.com.am.beans.Administrador;

public class CadastrarAdmin {

	public static void main(String[] args) {
			AdministradorDAO dao = null;
		try {
			AdministradorBO bo = new AdministradorBO();
			Administrador obj = new Administrador();
			obj.setNome("Pedro");
			obj.setSenha("1254");
			System.out.println(bo.novoAdministrador(obj));   
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
