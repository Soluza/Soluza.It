package br.com.am.principal;

import br.com.am.BO.AlunoBO;
import br.com.am.DAO.AlunoDAO;
import br.com.am.beans.Aluno;

public class DeletarAluno {
	public static void main(String[] args) {
		AlunoDAO dao = null;
		try {
			AlunoBO bo = new AlunoBO();
			Aluno a = new Aluno();
			System.out.println("Nome: " + a.getNome());
			System.out.println("CPF: " + a.getCpf());
			System.out.println("Email: " + a.getEmail());
			System.out.println("Senha: " + a.getSenha());
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try{ 
				dao.fechar();
			}catch(Exception e) {
				e.printStackTrace();
			}

		}
	}
}
