package br.com.am.principal;

import br.com.am.BO.DisciplinaBO;
import br.com.am.DAO.DisciplinaDAO;
import br.com.am.beans.Disciplina;

public class CadastrarDisciplina {

	public static void main(String[] args) {
		DisciplinaDAO dao = null;
		try {
		DisciplinaBO bo = new DisciplinaBO();
		Disciplina obj = new Disciplina();
		obj.setCodigo(123);
		obj.setNome("StartUps");
		obj.setStatus("ativo");
		System.out.println(bo.novaDisciplina(obj));
		
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
