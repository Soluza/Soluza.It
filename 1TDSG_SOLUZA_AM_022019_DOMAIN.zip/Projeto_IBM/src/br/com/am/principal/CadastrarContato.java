package br.com.am.principal;

import br.com.am.BO.ContatoBO;
import br.com.am.DAO.ContatoDAO;
import br.com.am.beans.Contato;

public class CadastrarContato {

	public static void main(String[] args) {
		ContatoDAO dao = null;
		try {
			ContatoBO bo = new ContatoBO();
			Contato obj = new Contato();
			obj.setMensagem("chegou a tao esperada hora, a de comer um grande e farto jantar.");
			System.out.println(bo.novoContato(obj));

		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}