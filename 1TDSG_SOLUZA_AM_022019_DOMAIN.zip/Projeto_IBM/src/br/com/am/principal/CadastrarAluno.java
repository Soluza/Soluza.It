package br.com.am.principal;

import br.com.am.BO.AlunoBO;
import br.com.am.DAO.AlunoDAO;
import br.com.am.beans.Aluno;

public class CadastrarAluno {

	public static void main(String[] args) {
		AlunoDAO dao = null;
		try {
			AlunoBO bo = new AlunoBO();
			Aluno obj = new Aluno();
			
			obj.setNome("JAVIER S");
			obj.setCpf("12345678910");
			obj.setEmail("JAVIER.B@GMAIL.COM");
			obj.setSenha("PIPOQUINHADOIDA123");
			System.out.println(bo.novoAluno(obj));
			

			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}

