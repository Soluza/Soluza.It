package br.com.am.BO;

import br.com.am.DAO.AprenderDAO;
import br.com.am.beans.Aprender;

/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Aprender
 */
public class AprenderBO {

	/**
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public String novoAprender(Aprender obj)throws Exception{
		if(obj.getCodigo() > 2) {
			return "Tamanho invalido!";
		}
		
		if(obj.getDataEntrada().toString().length() > obj.getDataSaida().toString().length()) {
			return "Data de entrada invalida";
		}
		
		AprenderDAO dao = new AprenderDAO();
		if(dao.adicionarAprender(obj) == 0) {
			dao.fechar();
			return "N�o cadastrada";
		}else {
			dao.fechar();
			return "Disciplina cadastrada com sucesso!!";
		}
	}
}
