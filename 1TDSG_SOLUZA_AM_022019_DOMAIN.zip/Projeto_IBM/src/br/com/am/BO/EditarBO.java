package br.com.am.BO;

import br.com.am.DAO.EditarDAO;
import br.com.am.beans.Editar;
/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Editar
 */
public class EditarBO {

	/**
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public String novoEditar(Editar obj) throws Exception {
		
		if(obj.getCodigo() > 4) {
			return "Codigo invalido!";
		}
		
		if(obj.getDataTermino().toString().length() > obj.getDataInicio().toString().length()) {
			return "Data invalida";
		}
		
		EditarDAO dao = new EditarDAO();
		if(dao.adicionarEditar(obj) == 0) {
			dao.fechar();
			return "Editar n�o cadastrado";
		}else {
			dao.fechar();
			return "Editar cadastrado com sucesso!";
		}
	}
}
