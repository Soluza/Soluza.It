package br.com.am.BO;

import br.com.am.DAO.ContatoDAO;
import br.com.am.beans.Contato;

/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Contato
 */
public class ContatoBO {
	/**
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public String novoContato(Contato obj) throws Exception {
		if(obj.getCodigo() > 3) {
			return "Codigo invalido";
		}

		if(obj.getMensagem().length() > 150) {
			return "Mensagem muito grande";
		}
		
		ContatoDAO dao = new ContatoDAO();
		if(dao.adicionarContato(obj)== 0) {
			dao.fechar();
			return "Contato n�o cadastrado";
		}else {
			dao.fechar();
			return "Contato adcionado com sucesso";
		}
	}
	

}
