package br.com.am.BO;

import br.com.am.DAO.DisciplinaDAO;
import br.com.am.beans.Disciplina;
/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Disciplina
 */
public class DisciplinaBO {


	/**
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public String novaDisciplina(Disciplina obj) throws Exception{
		if(obj.getCodigo() > 99) {
			return "Tamanho invalido!";
		}
		if(obj.getNome().length() > 30) {
			return "Tamanho invalido";
		}
		if(obj.getStatus().equals("ativo")) {	
			return "Disciplina ativa";
		}
	
		DisciplinaDAO dao = new DisciplinaDAO();
		if(dao.adicionarDisciplina(obj) == 0) {
			dao.fechar();
			return "N�o cadastrada";
		}else {
			dao.fechar();
			return "Disciplina cadastrada com sucesso!!";

		}
	}
}
