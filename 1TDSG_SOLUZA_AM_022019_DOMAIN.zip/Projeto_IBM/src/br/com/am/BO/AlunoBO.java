package br.com.am.BO;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import br.com.am.DAO.AlunoDAO;
import br.com.am.beans.Aluno;
import br.com.am.validacao.ValidarCpf;
/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Aluno
 */
public class AlunoBO {

	/**
	 * 
	 * @param email
	 * @return
	 * @throws Exception
	 */
	public Aluno consultarAlunoPeloEmail (String email) throws Exception{
		if(email == null) {
			return new Aluno();
		}
		AlunoDAO dao = new AlunoDAO();
		Aluno a = dao.getAluno(email);
		dao.fechar();
		return a;
	}

	/**
	 * 
	 * @param objAluno
	 * @return
	 * @throws Exception
	 */
	public String novoAluno(Aluno objAluno) throws Exception{

		objAluno.setEmail(objAluno.getEmail().toUpperCase());
		objAluno.setNome(objAluno.getNome().toUpperCase());

		if(objAluno.getNome().length()>60 || objAluno.getNome().length()<1) {
			return "Nome Inv�lido!";	
		}
		if(objAluno.getSenha().length() > 20) {
			return "Senha excedida!";
		}
		if(objAluno.getEmail().length() > 60) {
			return "Tamanho do Email excedido!";
		}
		AlunoDAO dao = new AlunoDAO();
		Aluno obj = dao.getAluno(objAluno.getEmail());

		class ValidarCpf {
			private String cpf;
			private void subsCaracteres() {
				cpf = cpf.replace("-", "");
				cpf = cpf.replace(".", "");
			}

			/**
			 * 
			 * @param cpf
			 * @return
			 */
			private boolean verificarTamanho(String cpf) {
				if(cpf.length() !=11) 
					return true;
				return false;
			}

			/**
			 * 
			 * @param cpf
			 * @return
			 */
			private boolean verificarNumeros(String cpf) {
				char priNum = '0' |  '9';	              
				char[] charCpf = cpf.toCharArray();
				for(char c: charCpf) {
					if(c != priNum)
						return false;		
				}
				return true;
			}
			
			/**
			 * 
			 * @param cpf
			 * @return
			 */
			private String calculoCpf(String cpf) {
				int resultCalc = 0;
				int mult = cpf.length()+1;
				char [] charCpf = cpf.toCharArray();

				for (int i=0; i<cpf.length(); i++) {
					resultCalc += (charCpf[i]-48) * mult--;

					int restoCalc = resultCalc % 11;
					if(restoCalc < 2) {
						resultCalc = 0;
					}else {
						resultCalc = 11 - restoCalc;
					}
				}
				return String.valueOf(resultCalc);

			}
			
			/**
			 * 
			 * @param cpf
			 * @return
			 */
			public boolean ValidarCpf(String cpf) {
				if(cpf == null) {
					return false;
				}else {
					String cpfGerado = "";
					cpf = cpf;

					subsCaracteres();
					if(verificarNumeros(cpf)) {
						return false;
					}
					if(verificarNumeros(cpf)) {
						return false;
					}
					cpfGerado = cpf.substring(0, 9);
					cpfGerado = cpfGerado.concat(calculoCpf(cpfGerado));
					cpfGerado = cpfGerado.concat(calculoCpf(cpfGerado));

					if(!cpfGerado.equals(cpf)) {
						return false;
					}
				}
				return true;
			}
		}

		if(dao.adicionarAluno(objAluno) == 0) {
			dao.fechar();
			return "N�o cadastrou";
		}else {
			dao.fechar();
			return "Aluno cadastrado com sucesso!!";

		}
	}
}
