package br.com.am.BO;

import br.com.am.DAO.AdministradorDAO;
import br.com.am.beans.Administrador;
import br.com.am.validacao.ValidarEmail;

/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Administrador 
 */
public class AdministradorBO {
	
	ValidarEmail val = new ValidarEmail();
	
	/**
	 * 
	 * @param admin
	 * @return
	 * @throws Exception
	 */
	public String novoAdministrador(Administrador admin) throws Exception{
		if(admin.getCodigo()<1 || admin.getCodigo()>9) {
			return "Codigo Invalido";
		}
		if(admin.getNome().length()>60) {
			return "Nome muito longo";
		}
		if(admin.getSenha().length()>20 ) {
			return "Senha muito longa!";
		}
		if(!admin.getEmail().equals(val)) {
			return "Email incorreto";					
		}
		
		AdministradorDAO dao = new AdministradorDAO();
		Administrador objeto = dao.getAdministrador(admin.getCodigo());
		if(dao.adicionarAdmin(admin)==0) {
			dao.fechar();
			return"Cadastro sem exito!";
		}else {
			dao.fechar();
			return"Cadastrado com sucesso";
		}
	}

}
