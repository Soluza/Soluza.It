package br.com.am.BO;

import br.com.am.DAO.CapituloDAO;
import br.com.am.beans.Capitulo;

/**
 * 
 * @author BRUNO CASTRO
 * @author THALLES FEIGE
 * @author LAYON GUIMAR�ES
 * @version 1.0.0
 * @see Capitulo
 */
public class CapituloBO {

	/**
	 * 
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public String novoCapitulo(Capitulo obj) throws Exception {
		if(obj.getCodigo() > 4) {
			return "Codigo invalido";
		}
		
		if(obj.getTitulo().length() > 30 || obj.getTitulo().length() < 1) {
			return "Titulo invalido";
		}
		
		CapituloDAO dao = new CapituloDAO();
		if(dao.adicionarCapitulo(obj) == 0) {
			dao.fechar();
			return "Capitulo n�o cadastrado";
		}else {
			dao.fechar();
			return "Capitulo adcionado com sucesso";
		}
	}
	
	
}
